 #include <Uefi.h>
 
 // e2048d00-7157-4df2-bfe6-2399f17b161a
 #define EFI_HIDDENKEYRECOVERY_SMM_PROTOCOL_GUID \
     { 0xe2048d00, 0x7157, 0x4df2, { 0xbf, 0xe6, 0x23, 0x99, 0xf1, 0x7b, 0x16, 0x1a } }
 
 extern EFI_GUID gEfiSmmHiddenKeyRecoveryProtocolGuid;
